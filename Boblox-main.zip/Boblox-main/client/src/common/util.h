// util.h — wire encoding helpers shared by the join client and the
// RbxTransport session (exact ports of py/probe5.py helpers).
#pragma once

#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#if defined(__linux__)
#include <unistd.h>
#endif

namespace rbx {

// Roblox compact varint (top-2-bit size scheme): stream framing + ctrl/chan
// messages. <0x40: 1B, <0x4000: 2B (0x40 prefix), <0x40000000: 4B (0x80),
// else 8B (0xC0). (probe5.compact_varint)
inline void compactVarint(std::vector<uint8_t>& out, uint64_t v) {
  if (v < 0x40) {
    out.push_back(uint8_t(v));
  } else if (v < 0x4000) {
    out.push_back(uint8_t(0x40 | (v >> 8)));
    out.push_back(uint8_t(v & 0xff));
  } else if (v < 0x40000000ull) {
    out.push_back(uint8_t(0x80 | (v >> 24)));
    out.push_back(uint8_t((v >> 16) & 0xff));
    out.push_back(uint8_t((v >> 8) & 0xff));
    out.push_back(uint8_t(v & 0xff));
  } else {
    out.push_back(uint8_t(0xC0 | (v >> 56)));
    out.push_back(uint8_t((v >> 48) & 0xff));
    out.push_back(uint8_t((v >> 40) & 0xff));
    out.push_back(uint8_t((v >> 32) & 0xff));
    out.push_back(uint8_t((v >> 24) & 0xff));
    out.push_back(uint8_t((v >> 16) & 0xff));
    out.push_back(uint8_t((v >> 8) & 0xff));
    out.push_back(uint8_t(v & 0xff));
  }
}

// Decode a compact varint at p. Returns bytes consumed (1/2/4/8) or 0 if
// the buffer is too short. (probe10.try_challenge walk)
inline size_t compactVarintDecode(const uint8_t* p, size_t len, uint64_t* v) {
  if (len < 1) return 0;
  size_t n = size_t(1) << (p[0] >> 6);
  if (n > len) return 0;
  uint64_t val = p[0] & 0x3f;
  for (size_t i = 1; i < n; i++) val = (val << 8) | p[i];
  *v = val;
  return n;
}

// Unsigned LEB128 (inner-field varint). (probe5.leb128)
inline void leb128(std::vector<uint8_t>& out, uint64_t v) {
  for (;;) {
    uint8_t b = uint8_t(v & 0x7f);
    v >>= 7;
    if (v) out.push_back(uint8_t(b | 0x80));
    else {
      out.push_back(b);
      break;
    }
  }
}

// Percent-decode (join-script fields like EphemeralEarlyPubKey and
// NetStackConfig arrive URL-encoded: base64 "...%3D" instead of "...=").
inline std::string percentDecode(const std::string& in) {
  std::string out;
  out.reserve(in.size());
  for (size_t i = 0; i < in.size(); ++i) {
    if (in[i] == '%' && i + 2 < in.size()) {
      int hi = -1, lo = -1;
      const char a = in[i + 1], b = in[i + 2];
      if (a >= '0' && a <= '9') hi = a - '0';
      else if (a >= 'a' && a <= 'f') hi = a - 'a' + 10;
      else if (a >= 'A' && a <= 'F') hi = a - 'A' + 10;
      if (b >= '0' && b <= '9') lo = b - '0';
      else if (b >= 'a' && b <= 'f') lo = b - 'a' + 10;
      else if (b >= 'A' && b <= 'F') lo = b - 'A' + 10;
      if (hi >= 0 && lo >= 0) {
        out.push_back(char((hi << 4) | lo));
        i += 2;
        continue;
      }
    }
    out.push_back(in[i]);
  }
  return out;
}

// Standard base64 decode with Python-b64decode semantics: non-alphabet chars
// are discarded, '=' padding tolerated; on structural failure returns the raw
// string bytes (early_auth_payload fallback).
inline std::string b64decode(const std::string& in) {
  static const char* alphabet =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  int vals[256];
  for (int i = 0; i < 256; i++) vals[i] = -1;
  for (int i = 0; alphabet[i]; i++) vals[(unsigned char)alphabet[i]] = i;
  std::vector<int> s;
  for (unsigned char c : in) if (vals[c] >= 0) s.push_back(vals[c]);
  std::string out;
  // group into 4-tuples; a leftover of 1 is invalid -> fallback
  size_t i = 0;
  while (i + 4 <= s.size()) {
    uint32_t quad = uint32_t((s[i] << 18) | (s[i + 1] << 12) | (s[i + 2] << 6) | s[i + 3]);
    out.push_back(char(quad >> 16));
    out.push_back(char((quad >> 8) & 0xff));
    out.push_back(char(quad & 0xff));
    i += 4;
  }
  size_t rem = s.size() - i;
  if (rem == 2) {
    uint32_t quad = uint32_t((s[i] << 18) | (s[i + 1] << 12));
    out.push_back(char(quad >> 16));
  } else if (rem == 3) {
    uint32_t quad = uint32_t((s[i] << 18) | (s[i + 1] << 12) | (s[i + 2] << 6));
    out.push_back(char(quad >> 16));
    out.push_back(char((quad >> 8) & 0xff));
  } else if (rem == 1) {
    // Python b64decode: data-char count %4 == 1 -> binascii.Error -> the
    // fallback (raw string bytes). Leftover bits of 2/3-char groups are
    // ignored by a2b_base64, so no padding-bit validation here.
    return in;
  }
  return out;
}

// Frame payload = compactVarint(len) + payload. (probe5.frame)
inline std::vector<uint8_t> frame(const uint8_t* p, size_t n) {
  std::vector<uint8_t> out;
  compactVarint(out, n);
  out.insert(out.end(), p, p + n);
  return out;
}
inline std::vector<uint8_t> frame(const std::vector<uint8_t>& payload) {
  return frame(payload.data(), payload.size());
}

// Stream header: [06 01 app][u32 BE chan]. (probe5.stream_header)
inline std::vector<uint8_t> streamHeader(uint32_t app, uint64_t chan) {
  return {0x06, 0x01, uint8_t(app), uint8_t(chan >> 24), uint8_t(chan >> 16),
          uint8_t(chan >> 8), uint8_t(chan)};
}

inline uint32_t be32(const uint8_t* p) {
  return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) | (uint32_t(p[2]) << 8) | p[3];
}
inline uint32_t le32(const uint8_t* p) {
  return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

// Random v4 UUID from the kernel (no external dep).
inline std::string uuid4() {
  std::string s;
  if (FILE* f = fopen("/proc/sys/kernel/random/uuid", "r")) {
    char buf[64];
    size_t n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f);
    buf[n] = 0;
    s = buf;
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r')) s.pop_back();
  }
  if (s.empty()) s = "00000000-0000-4000-8000-000000000000";
  return s;
}

inline std::string readFileBytes(const std::string& path, bool* ok) {
  FILE* f = fopen(path.c_str(), "rb");
  if (!f) {
    *ok = false;
    return "";
  }
  std::string out;
  char buf[65536];
  size_t n;
  while ((n = fread(buf, 1, sizeof buf, f)) > 0) out.append(buf, n);
  fclose(f);
  *ok = true;
  return out;
}

// A readable regular file. Used only to probe fixture locations; the real
// read still goes through readFileBytes.
inline bool fileReadable(const std::string& path) {
  FILE* f = fopen(path.c_str(), "rb");
  if (!f) return false;
  fclose(f);
  return true;
}

inline std::string pathBasename(const std::string& p) {
  const size_t s = p.find_last_of('/');
  return s == std::string::npos ? p : p.substr(s + 1);
}

inline std::string pathDirname(const std::string& p) {
  const size_t s = p.find_last_of('/');
  if (s == std::string::npos) return ".";
  if (s == 0) return "/";
  return p.substr(0, s);
}

// Absolute path of the running binary, or empty when unavailable.
inline std::string executablePath() {
#if defined(__linux__)
  char buf[4096];
  const ssize_t n = readlink("/proc/self/exe", buf, sizeof buf - 1);
  if (n > 0) return std::string(buf, size_t(n));
#endif
  return std::string();
}

// Locate a repo-relative fixture (the defaults under run/) independent of the
// working directory. `roblox` is normally launched from the repo root, but
// running ./roblox from build/client used to silently skip every join template
// (and with them the 0x90 join body, so the RCC never issued the 0x9B
// challenge). Tries the path as given, $BOBLOX_DATA_DIR/<name>, then walks up
// from the CWD and from the executable's directory. Returns `path` unchanged
// when nothing matches, so the caller's "missing" message still names it.
inline std::string resolveDataPath(const std::string& path) {
  if (path.empty() || path[0] == '/' || fileReadable(path)) return path;
  const std::string name = pathBasename(path);
  if (const char* dir = getenv("BOBLOX_DATA_DIR")) {
    if (*dir) {
      const std::string c = std::string(dir) + "/" + name;
      if (fileReadable(c)) return c;
    }
  }
#if defined(__linux__)
  char cwd[4096];
  if (getcwd(cwd, sizeof cwd)) {
    for (std::string dir = cwd;; dir = pathDirname(dir)) {
      const std::string c = dir + "/" + path;
      if (fileReadable(c)) return c;
      if (dir == "/") break;
    }
  }
#endif
  const std::string exe = executablePath();
  if (!exe.empty()) {
    for (std::string dir = pathDirname(exe);; dir = pathDirname(dir)) {
      const std::string c = dir + "/" + path;
      if (fileReadable(c)) return c;
      if (dir == "/" || dir == ".") break;
    }
  }
  return path;
}

// Whole-file read for callers that have an existing path (templates, saved
// joins). An unreadable path is empty, which every caller already treats as
// "absent" (the RakNet templates are optional).
inline std::vector<uint8_t> readFileVec(const std::string& path) {
  bool ok = false;
  const std::string s = readFileBytes(path, &ok);
  return std::vector<uint8_t>(s.begin(), s.end());
}

inline bool writeFileBytes(const std::string& path, const std::vector<uint8_t>& b) {
  FILE* f = fopen(path.c_str(), "wb");
  if (!f) return false;
  if (!b.empty()) fwrite(b.data(), 1, b.size(), f);
  fclose(f);
  return true;
}

inline std::string toLower(std::string s) {
  for (char& c : s)
    if (c >= 'A' && c <= 'Z') c = char(c - 'A' + 'a');
  return s;
}

} // namespace rbx
